=== Defier Portfolio ===
Contributors: Ehab
Tags: portfolio
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==


== Installation ==

= Installation =
1. Upload `Defier Shortcodes` to the `/wp-content/plugins/` directory

= Requirements =
* PHP 5.2.0 or later
* Wordpress 3.5 or later

== Changelog ==

= 1.0 =
* First Realease