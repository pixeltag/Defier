<?php
/*
Plugin Name: Defier Portfolio
Plugin URI: http://pixeltag.net
Description: Defier Portfolio add several Portfolio for  Defier themes.
Version: 1.0.1
Author: Ehab Yousef
Author URI: http://pixeltag.net
License: GPL2
*/


add_action('init', 'project_custom_init');

function project_custom_init()
{
    $labels = array(
        'name' => do_shortcode('Projects', 'defier'),
        'singular_name' => do_shortcode('Project', 'defier'),
        'add_new' => do_shortcode('Add New', 'defier'),
        'add_new_item' => do_shortcode('Add New Project' , 'defier'),
        'edit_item' => do_shortcode('Edit Project', 'defier'),
        'new_item' => do_shortcode('New Project', 'defier'),
        'view_item' => do_shortcode('View Project', 'defier'),
        'search_items' => do_shortcode('Search Projects', 'defier'),
        'not_found' =>  do_shortcode('No projects found', 'defier'),
        'not_found_in_trash' => do_shortcode('No projects found in Trash', 'defier'),
        'parent_item_colon' => '',
        'menu_name' => 'Portfolio'
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title','editor','author','thumbnail','excerpt','comments')
    );

    register_post_type('project',$args);

    // Initialize Taxonomy Labels
    $labels = array(
        'name' => __( 'Tags', 'defier' ),
        'singular_name' => __( 'Tag', 'defier' ),
        'search_items' =>  __( 'Search Types', 'defier' ),
        'all_items' => __( 'All Tags' , 'defier'),
        'parent_item' => __( 'Parent Tag' , 'defier'),
        'parent_item_colon' => __( 'Parent Tag:' , 'defier'),
        'edit_item' => __( 'Edit Tags' , 'defier'),
        'update_item' => __( 'Update Tag' , 'defier'),
        'add_new_item' => __( 'Add New Tag', 'defier' ),
        'new_item_name' => __( 'New Tag Name' , 'defier'),
    );

// Register Custom Taxonomy
    register_taxonomy('tagportfolio',array('project'), array(
        'hierarchical' => true, // define whether to use a system like tags or categories
        'labels' => $labels,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array( 'slug' => 'tag-portfolio' ),
    ));



}

add_filter('post_updated_messages', 'project_updated_messages');

function project_updated_messages( $messages ) {
    global $post, $post_ID;

    $messages['project'] = array(
        0 => '', // Unused. Messages start at index 1.
        1 => sprintf( do_shortcode('Project updated. <a href="%s">View project</a>', 'defier'), esc_url( get_permalink($post_ID) ) ),
        2 => do_shortcode('Custom field updated.', 'defier'),
        3 => do_shortcode('Custom field deleted.', 'defier'),
        4 => do_shortcode('Project updated.', 'defier'),
        /* translators: %s: date and time of the revision */
        5 => isset($_GET['revision']) ? sprintf( do_shortcode('Project restored to revision from %s', 'defier'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
        6 => sprintf( do_shortcode('Project published. <a href="%s">View project</a>', 'defier'), esc_url( get_permalink($post_ID) ) ),
        7 => do_shortcode('Project saved.', 'defier'),
        8 => sprintf( do_shortcode('Project submitted. <a target="_blank" href="%s">Preview project</a>', 'defier'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
        9 => sprintf( do_shortcode('Project scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview project</a>', 'defier'),
            // translators: Publish box date format, see http://php.net/date
            date_i18n( do_shortcode( 'M j, Y @ G:i' , 'defier'), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
        10 => sprintf( do_shortcode('Project draft updated. <a target="_blank" href="%s">Preview project</a>', 'defier'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
    );

    return $messages;
}


add_action('admin_init','portfolio_meta_init');

function portfolio_meta_init()
{
    add_meta_box('portfolio_meta', 'Project Info', 'portfolio_meta_setup', 'project', 'side', 'low');

    // add a callback function to save any data a user enters in
    add_action('save_post','portfolio_meta_save');
}

function portfolio_meta_setup()
{
    global $post;

    ?>
    <div class="portfolio_meta_control">
        <label>URL</label>
        <p>
            <input type="text" name="_url" value="<?php echo get_post_meta($post->ID,'_url',TRUE); ?>" style="width: 100%;" />
        </p>
    </div>
    <?php

    echo '<input type="hidden" name="meta_noncename" value="' . wp_create_nonce(__FILE__) . '" />';
}

function portfolio_meta_save($post_id)
{
    if (!isset($_POST['meta_noncename']) || !wp_verify_nonce($_POST['meta_noncename'], __FILE__)) {
        return $post_id;
    }

    if ('post' == $_POST['post_type']) {
        if (!current_user_can('edit_post', $post_id)) {
            return $post_id;
        }
    } elseif (!current_user_can('edit_page', $post_id)) {
        return $post_id;
    }

    if (defined('DOING_AUTOSAVE') == DOING_AUTOSAVE) {
        return $post_id;
    }

    if(isset($_POST['_url']))
    {
        update_post_meta($post_id, '_url', $_POST['_url']);
    } else
    {
        delete_post_meta($post_id, '_url');
    }
}
?>
