=== Defier Shortcodes ===
Plugin Name: Defier Post Like
Plugin URI: http://pixeltag.net
Description: Defier Post Like for  Defier themes.
Version: 0.5.2
Author: Jon Masterson
Author URI: http://jonmasterson.com/
License: 
Copyright (C) 2015 Jon Masterson
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Installation ==

= Installation =
1. Upload `Defier Shortcodes` to the `/wp-content/plugins/` directory

= Requirements =
* PHP 5.2.0 or later
* Wordpress 3.5 or later

== Changelog ==

= 1.0 =
* First Realease