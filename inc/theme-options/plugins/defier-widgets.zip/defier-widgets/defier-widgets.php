<?php
/*
Plugin Name: Defier Widgets
Plugin URI: http://pixeltag.net
Description: Defier Widgets add several widgets for  Defier themes.
Version: 1.0.1
Author: Ehab Yousef
Author URI: http://pixeltag.net
License: GPL2
*/



include_once dirname(__FILE__)  . '/widget-blocks/widget-125x125.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-300x250.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-about.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-ads.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-category.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-comments.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-facebook.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-flickr.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-google.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-instagram.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-latest-posts.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-login.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-popular-posts.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-sidebar.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-soundcloud.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-tabber.php';
include_once dirname(__FILE__)  . '/widget-blocks/widget-twitter.php';





?>